require('dotenv').config();
const express = require('express');
const cors = require('cors');
const nodemailer = require('nodemailer');

const app = express();
const port = process.env.PORT || 3001;

// Get allowed origins from environment variable or use default
const allowedOrigins = process.env.ALLOWED_ORIGINS 
  ? process.env.ALLOWED_ORIGINS.split(',') 
  : [
      'http://localhost:5173',
      'https://main.d3h6zszwagbc0j.amplifyapp.com'
    ];

// Middleware with specific CORS configuration
app.use(cors({
  origin: function(origin, callback) {
    // Allow requests with no origin (like mobile apps or curl requests)
    if (!origin) return callback(null, true);
    
    if (allowedOrigins.indexOf(origin) === -1) {
      console.log('Blocked CORS request from:', origin);
      const msg = 'The CORS policy for this site does not allow access from the specified Origin.';
      return callback(new Error(msg), false);
    }
    console.log('Allowed CORS request from:', origin);
    return callback(null, true);
  },
  methods: ['GET', 'POST'],
  allowedHeaders: ['Content-Type'],
  credentials: true
}));

app.use(express.json());

// Create transporter
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

// Verify transporter configuration
transporter.verify(function(error, success) {
  if (error) {
    console.log('Transporter verification error:', error);
  } else {
    console.log('Server is ready to send emails');
  }
});

// Test endpoint
app.get('/api/test', (req, res) => {
  console.log('Test endpoint hit');
  res.json({ message: 'Server is working!' });
});

// Email endpoint
app.post('/api/send-email', async (req, res) => {
  console.log('Received request at /api/send-email');
  console.log('Request body:', req.body);
  
  const { email } = req.body;

  if (!email) {
    console.log('No email provided in request');
    return res.status(400).json({ error: 'Email is required' });
  }

  try {
    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: process.env.EMAIL_TO,
      subject: 'New YPay Subscription',
      text: `New subscription request from: ${email}`,
      html: `
        <h2>New YPay Subscription</h2>
        <p>A new user has subscribed to YPay updates:</p>
        <p><strong>Email:</strong> ${email}</p>
        <p>Time: ${new Date().toLocaleString()}</p>
      `
    };

    console.log('Attempting to send email with options:', {
      from: mailOptions.from,
      to: mailOptions.to,
      subject: mailOptions.subject
    });

    const info = await transporter.sendMail(mailOptions);
    console.log('Email sent successfully:', info.response);
    
    res.status(200).json({ message: 'Email sent successfully' });
  } catch (error) {
    console.error('Detailed error sending email:', {
      message: error.message,
      code: error.code,
      stack: error.stack
    });
    res.status(500).json({ 
      error: 'Failed to send email',
      details: error.message 
    });
  }
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ error: 'Internal server error', details: err.message });
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
  console.log('Email configuration:', {
    user: process.env.EMAIL_USER,
    to: process.env.EMAIL_TO
  });
  console.log('Allowed origins:', allowedOrigins);
}); 