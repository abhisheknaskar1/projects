import React from 'react';
import ComingSoon from './pages/ComingSoon';
import './App.css';

function App() {
  return (
    <div className="App">
      <ComingSoon />
    </div>
  );
}

export default App; 