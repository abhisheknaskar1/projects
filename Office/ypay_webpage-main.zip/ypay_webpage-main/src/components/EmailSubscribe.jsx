import React, { useState, useEffect } from 'react';

// Use the appropriate API URL based on the environment
const API_URL = import.meta.env.PROD 
  ? import.meta.env.VITE_API_URL_PROD 
  : import.meta.env.VITE_API_URL_DEV;

const EmailSubscribe = () => {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isServerOnline, setIsServerOnline] = useState(false);

  // Check if server is online
  useEffect(() => {
    const checkServerStatus = async () => {
      try {
        console.log('Checking server status at:', `${API_URL}/api/test`);
        const response = await fetch(`${API_URL}/api/test`);
        console.log('Server response:', response);
        if (response.ok) {
          const data = await response.json();
          console.log('Server data:', data);
          setIsServerOnline(true);
        } else {
          console.log('Server response not OK');
          setIsServerOnline(false);
        }
      } catch (error) {
        console.error('Server check error:', error);
        setIsServerOnline(false);
      }
    };

    checkServerStatus();
    // Check every 30 seconds
    const interval = setInterval(checkServerStatus, 30000);
    return () => clearInterval(interval);
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setStatus('');
    setErrorMessage('');
    
    if (!isServerOnline) {
      setStatus('error');
      setErrorMessage('Server is not available. Please try again later.');
      setIsLoading(false);
      return;
    }

    try {
      console.log('Sending email request to:', `${API_URL}/api/send-email`);
      const response = await fetch(`${API_URL}/api/send-email`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email }),
      });

      console.log('Email response:', response);
      const data = await response.json();
      console.log('Email response data:', data);

      if (response.ok) {
        setStatus('success');
        setEmail('');
      } else {
        setStatus('error');
        setErrorMessage(data.details || 'Something went wrong. Please try again later.');
      }
    } catch (error) {
      console.error('Email submission error:', error);
      setStatus('error');
      setErrorMessage('Failed to connect to the server. Please try again later.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="w-full max-w-md mx-auto">
      {!isServerOnline && (
        <div className="mb-4 p-4 bg-yellow-50 rounded-lg">
          <p className="text-yellow-600 text-center">
            Server is not available. Please try again later.
          </p>
        </div>
      )}
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="relative">
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Enter your email address"
            className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
            required
            disabled={isLoading || !isServerOnline}
          />
          <button
            type="submit"
            disabled={isLoading || !isServerOnline}
            className={`mt-4 w-full px-6 py-3 text-white font-medium rounded-lg transition-all duration-200
              ${(isLoading || !isServerOnline)
                ? 'bg-gray-400 cursor-not-allowed' 
                : 'bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700'
              }`}
          >
            {isLoading ? 'Subscribing...' : 'Notify Me'}
          </button>
        </div>
      </form>
      
      {status === 'success' && (
        <div className="mt-4 p-4 bg-green-50 rounded-lg">
          <p className="text-green-600 text-center">
            Thank you for subscribing! We'll keep you updated.
          </p>
        </div>
      )}
      {status === 'error' && (
        <div className="mt-4 p-4 bg-red-50 rounded-lg">
          <p className="text-red-600 text-center">
            {errorMessage}
          </p>
        </div>
      )}
    </div>
  );
};

export default EmailSubscribe; 