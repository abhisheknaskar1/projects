import React from 'react';

const Header = () => {
  return (
    <header className="fixed top-0 left-0 w-full bg-white/90 backdrop-blur-sm z-50 shadow-sm">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-center">
          {/* Replace with your actual logo */}
          <div className="flex items-center space-x-2">
            <span className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              YPay
            </span>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header; 